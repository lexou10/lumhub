#!/usr/bin/env python3
"""
LumHub - Bouton physique GPIO 22
"""
import time
import subprocess
import socket
import signal
import sys
import gpiod

BUTTON_PIN = 22
SOCK_PATH  = '/run/lumhub-leds.sock'

def send_led(state):
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(SOCK_PATH)
        s.send(state.encode())
        s.close()
    except Exception:
        pass

chip = gpiod.Chip('gpiochip4')
line = chip.get_line(BUTTON_PIN)
line.request(consumer='lumhub-button', type=gpiod.LINE_REQ_DIR_IN, flags=gpiod.LINE_REQ_FLAG_BIAS_PULL_UP)

running = True
last_press_time = 0

def shutdown(sig, frame):
    global running
    running = False
    line.release()
    sys.exit(0)

signal.signal(signal.SIGTERM, shutdown)
signal.signal(signal.SIGINT, shutdown)

while running:
    if line.get_value() == 0:
        press_start = time.time()
        while line.get_value() == 0:
            time.sleep(0.05)
            if time.time() - press_start >= 10:
                send_led('warning')
                break

        duration = time.time() - press_start

        if duration >= 10:
            send_led('error')
            time.sleep(1)
            subprocess.call(['sudo', 'poweroff'])
        elif duration >= 3:
            send_led('warning')
            time.sleep(1)
            subprocess.call(['sudo', 'reboot'])
        else:
            now = time.time()
            if now - last_press_time < 0.5:
                send_led('debug')
            else:
                send_led('ok')
            last_press_time = now

    time.sleep(0.05)
