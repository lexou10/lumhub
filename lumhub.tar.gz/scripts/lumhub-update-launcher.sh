#!/bin/bash
/usr/local/bin/lumhub-updater.sh apply >> /var/log/lumhub-update.log 2>&1 &
