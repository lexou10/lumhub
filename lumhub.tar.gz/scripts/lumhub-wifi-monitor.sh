#!/bin/bash

CONFIG="/home/pi/homelumbox-server/data/config.json"
HOTSPOT="HomeLumBOX-AP"
CHECK_INTERVAL=30

get_ssid() {
  python3 -c "import json; d=json.load(open('$CONFIG')); print(d.get('wifi', {}).get('ssid', '') or '')" 2>/dev/null
}

get_password() {
  python3 -c "import json; d=json.load(open('$CONFIG')); print(d.get('wifi', {}).get('password', '') or '')" 2>/dev/null
}

is_wifi_connected() {
  nmcli -t -f TYPE,STATE con show --active | grep -q "^wifi:activated"
}

connect_wifi() {
  local SSID="$1"
  local PASSWORD="$2"
  nmcli con up "$SSID" 2>/dev/null && return 0
  if [ -n "$PASSWORD" ]; then
    nmcli device wifi connect "$SSID" password "$PASSWORD" ifname wlan0 2>/dev/null && return 0
  else
    nmcli device wifi connect "$SSID" ifname wlan0 2>/dev/null && return 0
  fi
  return 1
}

echo "[WiFi Monitor] Démarrage..."
nmcli radio wifi on
sleep 5

while true; do
  if is_wifi_connected; then
    if nmcli con show --active | grep -q "$HOTSPOT"; then
      echo "[WiFi Monitor] WiFi OK, désactivation hotspot"
      nmcli con down "$HOTSPOT" 2>/dev/null
    fi
  else
    echo "[WiFi Monitor] WiFi perdu, tentative de reconnexion..."
    SSID=$(get_ssid)
    PASSWORD=$(get_password)
    if [ -n "$SSID" ] && connect_wifi "$SSID" "$PASSWORD"; then
      echo "[WiFi Monitor] Reconnecté à $SSID"
      nmcli con down "$HOTSPOT" 2>/dev/null
    else
      echo "[WiFi Monitor] Échec, activation hotspot"
      nmcli con up "$HOTSPOT" 2>/dev/null
    fi
  fi
  sleep $CHECK_INTERVAL
done
