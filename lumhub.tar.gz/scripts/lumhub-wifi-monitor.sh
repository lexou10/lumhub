#!/bin/bash
# LumHub WiFi Monitor - Reconnexion automatique
INTERFACE="wlan0"
CHECK_INTERVAL=30
PING_HOST="8.8.8.8"

while true; do
    if ! ping -c 1 -W 3 $PING_HOST > /dev/null 2>&1; then
        echo "[WiFi] Connexion perdue, reconnexion..."
        nmcli device disconnect $INTERFACE 2>/dev/null
        sleep 2
        nmcli device connect $INTERFACE 2>/dev/null
        echo "[WiFi] Reconnexion tentée"
    fi
    sleep $CHECK_INTERVAL
done
